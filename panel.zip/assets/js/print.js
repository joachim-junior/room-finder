function myFunction() {
    window.print();
}