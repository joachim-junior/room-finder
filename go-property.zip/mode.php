<?php 
require 'include/reconfig.php';
echo $set['show_dark'];

?>