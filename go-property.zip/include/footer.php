<?php 
require 'include/reconfig.php';
echo $main['data'];
?>